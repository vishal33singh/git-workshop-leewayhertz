require("dotenv").config();
var db = require('./database/database').default;
const express = require("express");
const bcrypt = require('bcryptjs');
const app = express();
const jwt = require("jsonwebtoken")
const cmaster = require('cron-master');
const instance = cmaster.getInstance()
const auth = require('./middleware/auth');
var path = require('path');
app.use(express.urlencoded());

app.use(express.json());

app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});

/**
 * corn job loaded 
 * 
 */

 function initialiseJob (job) {
    console.log('Initialise Job: %s', job.meta.name)
  
    // Bind event name with your own string...
    job.on('tick-complete', function (err, result, time) {
      if (err) {
        console.error('job tick failed with error', err)
      } else {
        console.log('"%s" completed a tick in %dms', job.meta.name, time)
      }
    })
  
    // ...or bind using events object provided name
    job.on(cmaster.EVENTS.TIME_WARNING, function () {
      console.log('"%s" is taking longer than expected', job.meta.name)
    })
  
    job.on(cmaster.EVENTS.OVERLAPPING_CALL, function () {
      console.log('"%s" received a tick/call before the previous tick completed' +
        ' this tick has been ignored and will not run until the first tick ' +
        'has finished.', job.meta.name)
    })
  }
  
//  instance.loadJobs(path.join(__dirname, './jobs'), function (err, jobs) {
//     if (err) {
//       // Something went wrong when loading jobs
//       throw err
//     } else if (jobs.length === 0) {
//       // If no files were found
//       throw new Error('No jobs found!')
//     } else {
//       console.log('Initialising jobs...')
  
//       // Bind job events etc.
//       jobs.forEach(initialiseJob)
  
//       // Start the cron timers
//       instance.startJobs()
//     }
//   })



/**
 * corn job ends
 * 
 */
app.get('/api/getToken',(req,res)=>{
    var name = req.body.userName;
    var age =  req.body.age;
    var password = bcrypt.hash(req.body.password);
    const user = {
        name : name,
        age: age,
        password : password
    }

    const token = jwt.sign(
        { name: name },
        process.env.TOKEN_KEY,
        {
          expiresIn: "2h",
        }
      );

      user.token =token;
      res.status(200).json(user);
})

app.post('/api/validateToken',(req,res)=>{

})

app.post('/api/getUser',auth, (req, res) => {
  // var token = req.headers['x-access-token'];
  // if (!token) return res.status(401).send({ auth: false, message: 'No token provided.' });
  // const decodedToken = jwt.verify(token, process.env.TOKEN_KEY);
  // const userName = decodedToken.name;
  // console.log(process.env.TOKEN_KEY)
  // console.log(decodedToken)
  // console.log(userName)
  // if (req.body.name && req.body.name !== userName) {
  //   throw 'Invalid user ID';
  // } else {
       var user = {
        name: req.body.name
    }
    res.send(user);
  // }

    // var name = req.body.userName;
    // var age = req.body.age;
    // var id = req.body.id;
    // var sql = `INSERT INTO customer (name, age) VALUES ("${name}", "${age}")`;
    // db.query(sql, function (err, result) {
    //     if (err) throw err;
    //     console.log('record inserted');
    //     res.send(result);
    // });


})


module.exports = app;








// const express = require('express');
// const User = require('./model/user')
// const bcrypt = require('bcryptjs')
// require("dotenv").config();
// var db=require('./database/database').default;
// var app = express();
// app.use(express.urlencoded());

// app.use(express.json());
// app.use(function(req, res, next) {
//     res.setHeader('Access-Control-Allow-Origin', '*');
//     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
//     res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
//     res.setHeader('Access-Control-Allow-Credentials', true);
//     next();
// });


// app.post('/api/user', (req, res) => {
// 	var name=req.body.name;
// 	var age=req.body.age;
// 	var sql = `INSERT INTO customer (name, age) VALUES ("${name}", "${age}")`;
// 	db.query(sql, function(err, result) {
// 	  if (err) throw err;
// 	  console.log('record inserted');
// 	  res.send(result);
// 	});

//  })


// app.post('/api/register', async (req, res) => {
// 	const { username, password: plainTextPassword } = req.body

// 	if (!username || typeof username !== 'string') {
// 		return res.json({ status: 'error', error: 'Invalid username' })
// 	}

// 	if (!plainTextPassword || typeof plainTextPassword !== 'string') {
// 		return res.json({ status: 'error', error: 'Invalid password' })
// 	}

// 	if (plainTextPassword.length < 5) {
// 		return res.json({
// 			status: 'error',
// 			error: 'Password too small. Should be atleast 6 characters'
// 		})
// 	}

// 	const password = await bcrypt.hash(plainTextPassword, 10)

// 	try {
// 		const response = await User.create({
// 			username,
// 			password
// 		})
// 		console.log('User created successfully: ', response)
// 	} catch (error) {
// 		if (error.code === 11000) {
// 			// duplicate key
// 			return res.json({ status: 'error', error: 'Username already in use' })
// 		}
// 		throw error
// 	}

// 	res.json({ status: 'ok' })
// })

// app.listen(4005, () => {
// 	console.log('Server up at 4005');
// })


