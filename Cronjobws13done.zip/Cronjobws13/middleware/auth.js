const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  console.log("hi")
  try {
    // const token = req.headers.authorization.split(' ')[1];
    var token = req.headers['x-access-token'];
    const decodedToken = jwt.verify(token, process.env.TOKEN_KEY);
    const userName = decodedToken.name;
    console.log(process.env.TOKEN_KEY)
    if (req.body.name && req.body.name !== userName) {
      throw 'Invalid user ID';
    } else {
      next();
    }
  } catch {
    res.status(401).json({
      error: new Error('Invalid request!')
    });
  }
};