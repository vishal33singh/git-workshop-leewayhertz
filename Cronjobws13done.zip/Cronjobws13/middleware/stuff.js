const express = require('express');
const router = express.Router();

const auth = require('../middleware/auth');

const stuffCtrl = require('../controllers/stuff');

router.get('/', auth, stuffCtrl.getAllStuff);
router.post('/', auth, stuffCtrl.createThing);
router.get('/:name', auth, stuffCtrl.getOneThing);
router.put('/:name', auth, stuffCtrl.modifyThing);
router.delete('/:name', auth, stuffCtrl.deleteThing);

module.exports = router;