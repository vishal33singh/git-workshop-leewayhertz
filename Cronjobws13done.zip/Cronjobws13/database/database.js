const mysql = require('mysql');
var con = mysql.createConnection({

    host: "localhost",
    user: "root",
    password: "vishal33",
    database: "movieinfo",

});

con.connect(function (err) {
    if (err) throw err;
    console.log('Database is connected successfully !');
});

// export default con;