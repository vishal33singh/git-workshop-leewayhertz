var CronMasterJob = require('cron-master').CronMasterJob;
const fs = require('fs')
module.exports = new CronMasterJob({

  // Optional. Used to determine when to trigger the 'time-warning'. Fires after
  // the provided number of milliseconds (e.g 2 minutes in the case below) has
  // passed if the job has not called the done callback
  timeThreshold: 1000000,

  // Optional. Can be used to add useful meta data for a job
  meta: {
    name: 'Test Job'
  },

  // Just the usual params that you pass to the "cron" module!
  cronParams: {
    cronTime: '* * * * * *',
    onTick: function (job, done) {
        setTimeout(function () {
            fs.appendFile('./file/file.txt', "testing corn "+new Date()+"/n", err => {
                        if (err) {
                          console.error(err)
                          return
                        }
                    });
                    
            done(null, 'Example Job Result')
          }, 10000)
    //     fs.writeFile('./file/file', "testing corn "+new Date(), err => {
    //         if (err) {
    //           console.error(err)
    //           return
    //         }
    //     });
        
    //   done(null, 'ok');
    }
  }

});