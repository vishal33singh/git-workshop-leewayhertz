# Build a Dapp in 20 Minutes

Here are the tools we'll use in this tutorial:
1. Web3 JS - enables client side app to talk to blockchain
2. Metamask - enables browser to talk to blockchain
3. Ganache - local development blockchain
4. Remix - smart contract IDE
